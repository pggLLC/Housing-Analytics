Open ALL_IN_ONE_DEPLOYMENT_GUIDE.md for step-by-step deployment.
