# All‑in‑One Deployment Guide (GitHub Pages + Cloudflare Worker)

This package contains:
- The full website code ready for GitHub Pages deployment
- A Cloudflare Worker (no‑tech setup) that provides secure JSON endpoints:
  - `/prop123` (Prop 123 jurisdictions + commitments)
  - `/co-ami-gap` (Households vs priced‑affordable units by %AMI)

## 1) Upload the website to your existing GitHub repo

### A. Upload files
1. Open your GitHub repo in a browser.
2. Click **Add file → Upload files**.
3. Drag **everything inside this zip** (or upload the zip contents).
4. Commit the changes.

> Your repo already contains GitHub Actions workflows and secrets for Census/FRED.  
> This package keeps them and adds the missing pieces for the Colorado Deep Dive modules.

### B. Confirm GitHub Pages is enabled
1. Repo → **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` (or `master`) and folder `/ (root)`
4. Save

Wait for the site to build, then open your Pages URL.

## 2) Deploy the Cloudflare Worker (no coding tools needed)

### A. Create the Worker
1. Go to Cloudflare Dashboard → **Workers & Pages**
2. Click **Create application**
3. Choose **Workers**
4. Name it: `affordable-housing-api` (any name is fine)
5. Click **Deploy**
6. Open the Worker → **Edit code**

### B. Paste the Worker code
1. In this package, open: `cloudflare-worker/cloudflare-worker.js`
2. Copy **all** the text.
3. Paste it into the Cloudflare editor (replacing everything).
4. Click **Save and deploy**

### C. Add Worker secrets (keep tokens private)
1. Worker → **Settings** → **Variables and Secrets**
2. Add these **Secrets**:

- `HUD_USER_TOKEN` = your HUD USER API token (required for /co-ami-gap)
- `CENSUS_API_KEY` = your Census API key (recommended; reuse the same key you use in GitHub Actions)

Optional (non-secret) variables:
- `CACHE_TTL_SECONDS` = `86400` (1 day) or `604800` (7 days)
- `ALLOW_ORIGIN` = `*` (or your GitHub Pages domain)

### D. Test the Worker
Open these in a browser:
- `https://YOUR_WORKER_SUBDOMAIN.workers.dev/health`
- `https://YOUR_WORKER_SUBDOMAIN.workers.dev/prop123`
- `https://YOUR_WORKER_SUBDOMAIN.workers.dev/co-ami-gap`

You should see JSON.

## 3) Connect the website to the Worker (GitHub web editor)

### A. Edit `js/config.js`
1. In GitHub, open `js/config.js`
2. Find `window.APP_CONFIG = { ... }`
3. Add or update:

```js
PROP123_API_URL: "https://YOUR_WORKER_SUBDOMAIN.workers.dev/prop123",
AMI_GAP_API_URL: "https://YOUR_WORKER_SUBDOMAIN.workers.dev/co-ami-gap"
```

4. Commit the file.

### B. Refresh your site
Go to `colorado-deep-dive.html` and confirm:
- Map loads (county outlines visible)
- Prop 123 overlay toggle shows municipalities + counties with tooltips
- %AMI module loads data from the Worker (and not just the fallback)

## 4) Troubleshooting (common fixes)

### Map is blank
- This package sets `#coMap` height in `site-theme.css`.  
  If you have other CSS overriding it, ensure `#coMap` keeps a non‑zero height.

### Prop 123 overlay loads but no highlights
- Make sure `PROP123_API_URL` is correct.
- Ensure the Worker returns a JSON array of jurisdictions.

### AMI module shows “fallback”
- Make sure `AMI_GAP_API_URL` is correct.
- Ensure `HUD_USER_TOKEN` secret is set in Cloudflare.

### CORS error in browser console
- The Worker includes CORS headers.
- If you set `ALLOW_ORIGIN`, set it to your exact GitHub Pages origin, e.g. `https://pggllc.github.io`

## 5) What stays in GitHub Actions
Your existing Actions workflows for:
- FRED → `data/fred-data.json`
- Census ACS snapshot → `data/census-acs-state.json`

can remain unchanged. The Cloudflare Worker is used only for:
- Prop 123 live commitments JSON
- County %AMI affordability math JSON
